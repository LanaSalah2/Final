/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package librarysys;

/**
 *
 * @author user
 */
public class Journal extends Book {
     private String Conference_Name;
    private int Conference_No;
    public Journal (String tittle,Author a1,int no,Date d1,String gen,String edtion,String Conference_Name,int Conference_No) {
        super(tittle,a1,no,d1,gen,edtion);
        this.Conference_Name = Conference_Name;
        this.Conference_No = Conference_No;
    }

    public String getConference_Name() {
        return Conference_Name;
    }

    public void setConference_Name(String Conference_Name) {
        this.Conference_Name = Conference_Name;
    }

    public int getConference_No() {
        return Conference_No;
    }

    public void setConference_No(int Conference_No) {
        this.Conference_No = Conference_No;
    }
    
    @Override
    public String getInfo()
    {
        return super.getInfo()+ this.Conference_Name + this.Conference_No + super.getInfo();
    }
}
