/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package librarysys;

/**
 *
 * @author user
 */
public interface Display {
    public abstract String getInfo();
    public abstract boolean inLoan();
    
}
